# PHASE — landing page (web synth)

Regras obrigatórias do projeto. Leia este arquivo inteiro antes de qualquer tarefa.
O protótipo `phase-landing-previa.html` é a referência viva — replique o comportamento, não o código (ele é um arquivo único; aqui tudo é componentizado).

## O que é
Landing page de um produto fictício: PHASE, um synth de bolso que roda no navegador.
A página NÃO descreve o produto — ela É o produto. O hero é o instrumento, tocável de verdade.
Objetivo: peça de portfolio que impressiona. Prioridade: experiência e performance.

## Stack
- Next.js 15 (App Router) + TypeScript
- Áudio: Web Audio API nativa (sem biblioteca). Encapsulada na classe `SynthEngine`.
- Animação de scroll/entrada: gsap + @gsap/react + ScrollTrigger
- Scroll suave: lenis
- Sem Tailwind. CSS por componente em `.module.css`. Tokens globais em `styles/tokens.css`.

## REGRA DE OURO — áudio e visual são separados
- O `SynthEngine` é independente de React e de GSAP/Lenis. Nunca recriar o `AudioContext` em re-render.
- Uma única instância de `SynthEngine` no app (via hook `useSynth` / contexto).
- O `AudioContext` só é criado no primeiro gesto do usuário (clique/tecla) — política de autoplay.
- GSAP e Lenis tocam SÓ o visual. Nunca agendam áudio. Nunca rodam no caminho do som.
- O osciloscópio lê o `AnalyserNode` no seu próprio requestAnimationFrame; esse rAF nunca bloqueia nem depende da timeline do GSAP.
- Mudança de parâmetro de áudio (cutoff etc.) usa `setTargetAtTime`, nunca seta `.value` direto durante interação (evita estalo).

## Identidade visual
- Tema padrão: dark "studio" (preto quente + LEDs de hardware). Tema alternativo: paper (claro/suíço). Trocável via `data-theme` no `<html>`. Todas as cores vêm de `tokens.css` — nunca hardcode hex em componente.
- Sinais com função: `--signal` (âmbar) = ação/som/ativo; `--accent` (fósforo) = status/vivo. Fundo = silêncio.
- Tipografia: `--font-disp` Syne (marca/headlines), `--font-sans` Hanken Grotesk (texto), `--font-mono` Martian Mono (rótulos técnicos, specs, valores).
- Glow só no que está ativo; o resto fica no escuro. Glow é função, não decoração.
- Componentes táteis: afundam 2–3px no clique, pads acendem LED, como hardware.

## Animação — lei do projeto
- Todo scroll usa Lenis. Nunca scroll nativo. Nunca `window.addEventListener('scroll')` com Lenis ativo.
- Lenis inicializado UMA vez (Provider no `layout.tsx`) e alimenta o ScrollTrigger: `lenis.on('scroll', ScrollTrigger.update)`.
- Animação de entrada sempre em GSAP, nunca CSS transition. CSS transition só para hover/micro-interação e para o feedback tátil dos controles.
- Ease padrão: `power3.out`. Permitidos: power3, power4, expo, sine. Loops infinitos: `sine.inOut`.
- Proibido: bounce, elastic, ease-in-out.
- Duration de entrada >= 0.6s (alvo 0.7–0.9s). Micro-interação/feedback de toque < 0.25s.
- translateY de entrada entre 24px e 60px. Stagger entre 0.08s e 0.12s.
- 0.4s de silêncio antes da timeline do hero começar.
- Princípio: lento com intenção. O ritmo certo é o que o usuário não percebe, só sente peso.

## Acessibilidade — obrigatório
- Respeitar `prefers-reduced-motion` via `gsap.matchMedia()`: desliga entrada animada, parallax/scrub e movimento decorativo. O ÁUDIO continua 100% funcional; o osciloscópio pode ficar estático ou com refresh reduzido.
- O teclado visual é tocável pelo teclado físico (mapa A S D F G H J K + W E T Y U) E navegável/acionável por teclado (role apropriado, foco visível, Enter/Espaço dispara nota).
- Foco sempre visível. Nenhuma decoração captura eventos de acessibilidade (`pointer-events:none` em camadas visuais).
- Contraste mínimo AA para texto sobre `--bg` e `--surface`.

## Performance — obrigatório
- Um único rAF para o osciloscópio. Pausa quando o canvas sai da viewport (IntersectionObserver) e quando a aba perde foco (`visibilitychange`).
- Polifonia limitada (maxVoices = 8) com voice stealing. Desconectar nós de voz no `onended`.
- Imagens/og em lazy-load. Fonts com `display=swap`.

## Componentes
- Um componente = um `.tsx` + um `.module.css`. Sem exceções.
- Tudo que toca áudio, canvas ou GSAP é `'use client'`. O resto fica server component.
- Componente com GSAP: `useGSAP` do @gsap/react com cleanup (`revert`).
- Tipografia e espaçamento crítico em `clamp()`, nunca px fixo.

## O que nunca fazer
- recriar o AudioContext em render, ou ter mais de uma instância de SynthEngine
- deixar GSAP/Lenis no caminho do áudio
- ease-in-out, bounce, elastic
- duration "redonda" tipo 500ms/1000ms (use 0.7s, 0.9s…)
- scroll nativo com Lenis ativo
- hex hardcoded em componente (use tokens)
- qualquer animação sem fallback de reduced-motion

## Fluxo de trabalho
- Antes de codar uma seção, descreva comportamento + timing, confirme, depois implemente.
- Mudou animação em lote? Liste arquivo/linha/mudança e aguarde aprovação antes de aplicar.
